Before use:
✔ Before using this program, it is not necessary to install MATLAB, but the MCR compiler must be installed! You can download the file at this address:
https://www.mathworks.com/products/compiler/matlab-runtime.html
✔ Attached files (templates) are the templates for data importing.

Introduction for this toolkit:
✔ The Airflow Analytical Toolkit (AAT) includes a velocity analytical toolbox and a direction analytical toolbox. The velocity toolkit supports four types of data import methods: Swema03 hot ball anemometer <two formats>, RM YOUNG 81000 ultrasonic anemometer, and a generic format, while the direction analytical toolbox currently supports the sample collected by RM YOUNG 81000 only. We suggest the required sampling frequency of the airflow measurement should be more than 10 Hz, the minimum sampling duration should be 409.5 s (when f=10 Hz) at least.
✔ For airflow measurement, the following paper can be referred:
Xie, Z., Xie, Y., Cao, B., & Zhu, Y. (2023). A study of the characteristics of dynamic incoming flow directions of different airflows and their influence on wind comfort. Building and Environment, 110861. https://doi.org/10.1016/j.buildenv.2023.110861
Ouyang, Q. et al., (2006). Study on dynamic characteristics of natural and mechanical wind in built environment using spectral analysis. Building and Environment, 41(4), pp.418–426.
✔ Data import-calculation-export (Velocity box as an example):
Import → Click to time series plot → Basic parameters calculation → Spectrum analysis → Chaos analysis → Wavelet transform → Other parameters → Export (Note: Calculating relevant dimensions takes about 3 to 5 minutes. It is recommended to calculate at the end or only for specific analyses)
✔ Unfortunately, the current toolkit has limited support for sample types collected by different airflow measurements. If you are using a various anemometer, you can import data using a <generic format> file. In addition, the wind direction tool currently only supports RM 81000 ultrasonic sample import. We will expand the sample library of the toolbox in the future.
✔ If you have any questions, please feel free to ask!
email-address: Zuoyu Xie, xiezy21@mails.tsinghua.edu.

◆◆◆用前准备◆◆◆
✔ 使用本程序前无须要求安装MATLAB，但须安装MCR编译器！！！因此使用前请双击压缩包的<MCR_R2018b_win64_installer.exe>进行安装！！！
MCR介绍：GUI封装成exe后，内部计算时涉及<m.file>的算法，为了使没有安装MATLAB软件的计算机能够调用这些<m.file>，MCR可以提供能够使这些<m.file>运行所必需的运行库。
✔ 安装后将压缩包内的解压到硬盘路径即可。若追求打开程序后显示清华大学TECH logo的效果，splash.png文件务必要和exe为同一路径。<建议安装后将AAT.exe文件发送快捷方式到桌面>

◆◆◆程序介绍◆◆◆
✔ 数据导入 ——> 导入格式参照压缩包内模板附件
【本软件目前支持四种导入方式：Swema03热球风速仪<两种格式>，RM YOUNG 81000超声波风速仪，通用格式】
【前两者为txt格式，为仪器默认导出的数据；通用格式为xlsx，要求第一列为时间，第二列为风速/风向，均要求起始于第一行】
✔ 数据计算
【以下为建议计算步骤，仅供参考】
导入→点击绘制时序图→基本特征→谱分析→混沌分析→小波变换→其他参数→导出（注：相关维数计算耗时约3~5分钟，建议在最后计算或只对特殊样本计算）
✔ 数据导出
【导出数据：直接选择导出路径，会自动生成名为"XX_res.xlsx"的文件，文件包含所有已计算得到的数据】
【导出图片：方式1——得到的绘图不要关闭，导出图片并选择路径后只会对已打开的图片进行保存与导出；方式2——对于只想导出的特定图片<如CWT>点击绘制后可在小窗另存为加强版的矢量图emf】

◆◆◆制作者信息◆◆◆
谢作宇 <xiezy21@mails.tsinghua.edu>
清华大学建筑学院热舒适课题组           

◆◆◆Last updated◆◆◆
2023/5/7

在使用过程中若发现bug等数据分析方法的错误，欢迎批评指正！